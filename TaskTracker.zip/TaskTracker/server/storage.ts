import { User, InsertUser, Task, InsertTask, StudyGroup, GroupMember, GroupMessage, InsertGroup, InsertMessage } from "@shared/schema";
import session from "express-session";
import createMemoryStore from "memorystore";

const MemoryStore = createMemoryStore(session);

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  getTasks(userId: number): Promise<Task[]>;
  createTask(userId: number, task: InsertTask): Promise<Task>;
  updateTask(taskId: number, updates: Partial<Task>): Promise<Task>;
  deleteTask(taskId: number): Promise<void>;

  // Study group methods
  createGroup(ownerId: number, group: InsertGroup): Promise<StudyGroup>;
  getGroup(groupId: number): Promise<StudyGroup | undefined>;
  getGroupMembers(groupId: number): Promise<GroupMember[]>;
  getGroupMessages(groupId: number): Promise<GroupMessage[]>;
  addGroupMember(groupId: number, userId: number): Promise<GroupMember>;
  createGroupMessage(groupId: number, userId: number, message: InsertMessage): Promise<GroupMessage>;
  getUserGroups(userId: number): Promise<StudyGroup[]>;

  sessionStore: session.Store;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private tasks: Map<number, Task>;
  private groups: Map<number, StudyGroup>;
  private groupMembers: Map<number, GroupMember>;
  private groupMessages: Map<number, GroupMessage>;
  private currentUserId: number;
  private currentTaskId: number;
  private currentGroupId: number;
  private currentGroupMemberId: number;
  private currentMessageId: number;
  sessionStore: session.Store;

  constructor() {
    this.users = new Map();
    this.tasks = new Map();
    this.groups = new Map();
    this.groupMembers = new Map();
    this.groupMessages = new Map();
    this.currentUserId = 1;
    this.currentTaskId = 1;
    this.currentGroupId = 1;
    this.currentGroupMemberId = 1;
    this.currentMessageId = 1;
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000,
    });
  }

  // Existing user and task methods...
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async getTasks(userId: number): Promise<Task[]> {
    return Array.from(this.tasks.values()).filter(
      (task) => task.userId === userId,
    );
  }

  async createTask(userId: number, insertTask: InsertTask): Promise<Task> {
    const id = this.currentTaskId++;
    const task: Task = {
      ...insertTask,
      id,
      userId,
      completed: false,
    };
    this.tasks.set(id, task);
    return task;
  }

  async updateTask(taskId: number, updates: Partial<Task>): Promise<Task> {
    const task = this.tasks.get(taskId);
    if (!task) throw new Error("Task not found");

    const updatedTask = { ...task, ...updates };
    this.tasks.set(taskId, updatedTask);
    return updatedTask;
  }

  async deleteTask(taskId: number): Promise<void> {
    this.tasks.delete(taskId);
  }

  // New study group methods
  async createGroup(ownerId: number, group: InsertGroup): Promise<StudyGroup> {
    const id = this.currentGroupId++;
    const newGroup: StudyGroup = {
      ...group,
      id,
      ownerId,
      createdAt: new Date(),
    };
    this.groups.set(id, newGroup);

    // Automatically add owner as member
    await this.addGroupMember(id, ownerId);
    return newGroup;
  }

  async getGroup(groupId: number): Promise<StudyGroup | undefined> {
    return this.groups.get(groupId);
  }

  async getGroupMembers(groupId: number): Promise<GroupMember[]> {
    return Array.from(this.groupMembers.values()).filter(
      (member) => member.groupId === groupId
    );
  }

  async getGroupMessages(groupId: number): Promise<GroupMessage[]> {
    return Array.from(this.groupMessages.values())
      .filter((msg) => msg.groupId === groupId)
      .sort((a, b) => a.sentAt.getTime() - b.sentAt.getTime());
  }

  async addGroupMember(groupId: number, userId: number): Promise<GroupMember> {
    const id = this.currentGroupMemberId++;
    const member: GroupMember = {
      id,
      groupId,
      userId,
      joinedAt: new Date(),
    };
    this.groupMembers.set(id, member);
    return member;
  }

  async createGroupMessage(groupId: number, userId: number, message: InsertMessage): Promise<GroupMessage> {
    const id = this.currentMessageId++;
    const newMessage: GroupMessage = {
      ...message,
      id,
      groupId,
      userId,
      sentAt: new Date(),
    };
    this.groupMessages.set(id, newMessage);
    return newMessage;
  }

  async getUserGroups(userId: number): Promise<StudyGroup[]> {
    const memberGroups = Array.from(this.groupMembers.values())
      .filter((member) => member.userId === userId)
      .map((member) => member.groupId);

    return Array.from(this.groups.values())
      .filter((group) => memberGroups.includes(group.id));
  }
}

export const storage = new MemStorage();