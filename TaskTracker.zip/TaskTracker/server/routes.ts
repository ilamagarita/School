import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from "ws";
import { setupAuth } from "./auth";
import { storage } from "./storage";
import { insertTaskSchema, insertGroupSchema, insertMessageSchema } from "@shared/schema";
import { z } from "zod";
import { format } from "date-fns";

interface ChatMessage {
  type: 'message';
  groupId: number;
  content: string;
}

interface WebSocketWithUserId extends WebSocket {
  userId?: number;
}

export async function registerRoutes(app: Express): Promise<Server> {
  setupAuth(app);

  // Task management routes
  app.get("/api/tasks", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const tasks = await storage.getTasks(req.user.id);
    res.json(tasks);
  });

  app.post("/api/tasks", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    try {
      const taskData = insertTaskSchema.parse(req.body);
      const task = await storage.createTask(req.user.id, taskData);
      res.status(201).json(task);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json(error.errors);
      } else {
        throw error;
      }
    }
  });

  app.patch("/api/tasks/:id", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const taskId = parseInt(req.params.id);
    const task = await storage.updateTask(taskId, req.body);
    res.json(task);
  });

  app.delete("/api/tasks/:id", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const taskId = parseInt(req.params.id);
    await storage.deleteTask(taskId);
    res.sendStatus(204);
  });

  // Study group routes
  app.post("/api/groups", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    try {
      const groupData = insertGroupSchema.parse(req.body);
      const group = await storage.createGroup(req.user.id, groupData);
      res.status(201).json(group);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json(error.errors);
      } else {
        throw error;
      }
    }
  });

  app.get("/api/groups", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const groups = await storage.getUserGroups(req.user.id);
    res.json(groups);
  });

  app.get("/api/groups/:id", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const groupId = parseInt(req.params.id);
    const group = await storage.getGroup(groupId);
    if (!group) return res.sendStatus(404);

    const [members, messages] = await Promise.all([
      storage.getGroupMembers(groupId),
      storage.getGroupMessages(groupId),
    ]);

    res.json({ group, members, messages });
  });

  app.post("/api/groups/:id/join", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const groupId = parseInt(req.params.id);
    const member = await storage.addGroupMember(groupId, req.user.id);
    res.status(201).json(member);
  });

  // Enhanced AI chat endpoint with scheduling capabilities
  app.post("/api/chat", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);

    try {
      // Get user's existing tasks for context
      const tasks = await storage.getTasks(req.user.id);
      const scheduledTasks = tasks.map(task => ({
        title: task.title,
        dueDate: format(new Date(task.dueDate), 'yyyy-MM-dd HH:mm'),
        completed: task.completed
      }));

      // Create a context-aware system message
      const systemMessage = `You are a helpful AI study assistant with scheduling capabilities.
Current tasks on schedule:
${JSON.stringify(scheduledTasks, null, 2)}

Based on this schedule:
1. If the user asks about scheduling, analyze the existing tasks and suggest optimal times
2. Consider task dependencies and spacing
3. Avoid scheduling conflicts
4. Provide clear rationale for scheduling suggestions
5. Format times in a clear, readable way`;

      const response = await fetch("https://api.perplexity.ai/chat/completions", {
        method: "POST",
        headers: {
          "Authorization": `Bearer ${process.env.PERPLEXITY_API_KEY || ""}`,
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          model: "llama-3.1-sonar-small-128k-online",
          messages: [
            {
              role: "system",
              content: systemMessage
            },
            {
              role: "user",
              content: req.body.message
            }
          ],
          temperature: 0.2
        })
      });

      const data = await response.json();

      // If the response suggests a schedule, try to parse and create tasks
      const aiMessage = data.choices[0].message;

      // Check if the message contains scheduling suggestions
      if (req.body.message.toLowerCase().includes('schedule') &&
          aiMessage.content.toLowerCase().includes('suggest')) {
        res.json({
          ...aiMessage,
          scheduleSuggestion: true
        });
      } else {
        res.json(aiMessage);
      }
    } catch (error) {
      console.error('AI chat error:', error);
      res.status(500).json({ error: "Failed to get AI response" });
    }
  });

  // Update the /api/schedule/suggest endpoint to parse and create tasks
  app.post("/api/schedule/suggest", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);

    try {
      const tasks = await storage.getTasks(req.user.id);

      // Get AI suggestion for task scheduling
      const response = await fetch("https://api.perplexity.ai/chat/completions", {
        method: "POST",
        headers: {
          "Authorization": `Bearer ${process.env.PERPLEXITY_API_KEY || ""}`,
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          model: "llama-3.1-sonar-small-128k-online",
          messages: [
            {
              role: "system",
              content: `You are a scheduling assistant. Based on this schedule:
${JSON.stringify(tasks, null, 2)}

Analyze the user's request and suggest optimal study times. 
Respond in JSON format only with an array of tasks, each containing:
{
  "title": "string",
  "description": "string",
  "dueDate": "ISO date string"
}`
            },
            {
              role: "user",
              content: req.body.suggestion
            }
          ],
          temperature: 0.2,
          response_format: { type: "json_object" }
        })
      });

      const data = await response.json();
      const suggestedTasks = JSON.parse(data.choices[0].message.content);

      // Create the suggested tasks
      const createdTasks = await Promise.all(
        suggestedTasks.tasks.map(task =>
          storage.createTask(req.user.id, {
            title: task.title,
            description: task.description || "",
            dueDate: new Date(task.dueDate)
          })
        )
      );

      res.json({ tasks: createdTasks });
    } catch (error) {
      console.error("Scheduling error:", error);
      res.status(500).json({ error: "Failed to process scheduling suggestion" });
    }
  });

  // Create HTTP server
  const httpServer = createServer(app);

  // Set up WebSocket server for real-time chat
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });

  wss.on('connection', (ws: WebSocketWithUserId) => {
    ws.on('message', async (data: string) => {
      try {
        const message = JSON.parse(data) as ChatMessage;

        if (ws.userId) {
          const newMessage = await storage.createGroupMessage(
            message.groupId,
            ws.userId,
            { content: message.content }
          );

          // Broadcast to all connected clients in the same group
          wss.clients.forEach((client: WebSocketWithUserId) => {
            if (client.readyState === WebSocket.OPEN) {
              client.send(JSON.stringify({
                type: 'message',
                groupId: message.groupId,
                message: newMessage,
              }));
            }
          });
        }
      } catch (error) {
        console.error('WebSocket message error:', error);
      }
    });
  });

  return httpServer;
}