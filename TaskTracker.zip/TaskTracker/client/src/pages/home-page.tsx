import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import TaskCalendar from "@/components/task-calendar";
import ChatWindow from "@/components/chat-window";
import TaskForm from "@/components/task-form";
import StudyGroups from "@/components/study-groups";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { Calendar, LogOut, Menu, MessageSquare, Settings, Users } from "lucide-react";
import { useState } from "react";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

export default function HomePage() {
  const { user, logoutMutation } = useAuth();
  const [showChat, setShowChat] = useState(false);

  return (
    <div className="min-h-screen bg-background">
      <nav className="border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16">
            <div className="flex">
              <Sheet>
                <SheetTrigger asChild>
                  <Button variant="ghost" size="icon" className="md:hidden">
                    <Menu className="h-5 w-5" />
                  </Button>
                </SheetTrigger>
                <SheetContent side="left">
                  <div className="mt-4 space-y-4">
                    <h2 className="text-lg font-semibold">Quick Actions</h2>
                    <TaskForm />
                  </div>
                </SheetContent>
              </Sheet>
              <div className="flex-shrink-0 flex items-center">
                <h1 className="text-xl font-bold">StudyBuddy</h1>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <Button variant="ghost" size="icon">
                <Users className="h-5 w-5" />
              </Button>
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setShowChat(!showChat)}
              >
                <MessageSquare className="h-5 w-5" />
              </Button>
              <Button variant="ghost" size="icon">
                <Settings className="h-5 w-5" />
              </Button>
              <Button
                variant="ghost"
                size="icon"
                onClick={() => logoutMutation.mutate()}
              >
                <LogOut className="h-5 w-5" />
              </Button>
            </div>
          </div>
        </div>
      </nav>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid md:grid-cols-[300px_1fr] gap-8">
          <div className="hidden md:block space-y-8">
            <div className="sticky top-8">
              <ScrollArea className="h-[calc(100vh-8rem)]">
                <div className="pr-4 space-y-8">
                  <TaskForm />
                </div>
              </ScrollArea>
            </div>
          </div>
          <div className="space-y-8">
            <Tabs defaultValue="dashboard">
              <TabsList>
                <TabsTrigger value="dashboard">Dashboard</TabsTrigger>
                <TabsTrigger value="groups">Study Groups</TabsTrigger>
              </TabsList>

              <TabsContent value="dashboard" className="mt-6">
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-2xl font-bold">Your Dashboard</h2>
                  <Calendar className="h-5 w-5" />
                </div>
                <TaskCalendar />
              </TabsContent>

              <TabsContent value="groups" className="mt-6">
                <StudyGroups />
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </div>

      {showChat && (
        <div className="fixed bottom-4 right-4 w-96">
          <ChatWindow onClose={() => setShowChat(false)} />
        </div>
      )}
    </div>
  );
}