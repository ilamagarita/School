import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Calendar, X } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useQueryClient } from "@tanstack/react-query";

interface Message {
  role: "assistant" | "user";
  content: string;
  scheduleSuggestion?: boolean;
}

export default function ChatWindow({ onClose }: { onClose: () => void }) {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  const handleSchedulingSuggestion = async (content: string) => {
    try {
      setIsLoading(true);
      const response = await apiRequest("POST", "/api/schedule/suggest", {
        suggestion: content
      });
      const data = await response.json();

      if (data.tasks?.length > 0) {
        toast({
          title: "Schedule Updated",
          description: `Created ${data.tasks.length} new tasks based on AI suggestions`,
        });
        // Force a refresh of the task list
        queryClient.invalidateQueries({ queryKey: ["/api/tasks"] });
      }
    } catch (error) {
      toast({
        title: "Failed to update schedule",
        description: "Could not apply the scheduling suggestions",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const sendMessage = async () => {
    if (!input.trim() || isLoading) return;

    const userMessage = { role: "user" as const, content: input };
    setMessages((prev) => [...prev, userMessage]);
    setInput("");
    setIsLoading(true);

    try {
      const response = await apiRequest("POST", "/api/chat", {
        message: input,
      });
      const data = await response.json();

      setMessages((prev) => [...prev, {
        role: "assistant",
        content: data.content,
        scheduleSuggestion: data.scheduleSuggestion
      }]);

      if (data.scheduleSuggestion) {
        await handleSchedulingSuggestion(data.content);
      }
    } catch (error) {
      console.error("Failed to get AI response:", error);
      toast({
        title: "Error",
        description: "Failed to get AI response",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Card className="shadow-lg">
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle>AI Study Assistant</CardTitle>
        <Button
          variant="ghost"
          size="icon"
          onClick={onClose}
          className="h-8 w-8 p-0"
        >
          <X className="h-4 w-4" />
        </Button>
      </CardHeader>
      <CardContent>
        <ScrollArea className="h-[400px] pr-4">
          <div className="space-y-4">
            {messages.map((message, i) => (
              <div
                key={i}
                className={`flex ${
                  message.role === "user" ? "justify-end" : "justify-start"
                }`}
              >
                <div
                  className={`rounded-lg px-4 py-2 max-w-[80%] ${
                    message.role === "user"
                      ? "bg-primary text-primary-foreground"
                      : "bg-muted"
                  }`}
                >
                  {message.content}
                  {message.scheduleSuggestion && (
                    <div className="mt-2 flex items-center gap-2 text-xs">
                      <div className="flex items-center text-primary">
                        <Calendar className="h-4 w-4 mr-1" />
                        Scheduling suggestions applied
                      </div>
                      <Button
                        variant="ghost"
                        size="sm"
                        className="h-6 px-2"
                        onClick={() => queryClient.invalidateQueries({ queryKey: ["/api/tasks"] })}
                      >
                        Refresh Calendar
                      </Button>
                    </div>
                  )}
                </div>
              </div>
            ))}
            {isLoading && (
              <div className="flex justify-start">
                <div className="bg-muted rounded-lg px-4 py-2">
                  Analyzing schedule...
                </div>
              </div>
            )}
          </div>
        </ScrollArea>
        <div className="flex gap-2 mt-4">
          <Input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyPress={(e) => e.key === "Enter" && sendMessage()}
            placeholder="Ask about scheduling or any study questions..."
            disabled={isLoading}
          />
          <Button onClick={sendMessage} disabled={isLoading}>
            Send
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}